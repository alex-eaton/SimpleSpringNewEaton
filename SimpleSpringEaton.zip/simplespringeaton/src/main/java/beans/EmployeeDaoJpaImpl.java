package beans;

import java.util.List;

public class EmployeeDaoJpaImpl implements EmployeeDAO{

	public void insert(Employee employee) {
		// TODO Auto-generated method stub
		
	}

	public void update(Employee employee) {
		// TODO Auto-generated method stub
		
	}

	public void update(List<Employee> employees) {
		// TODO Auto-generated method stub
		
	}

	public void delete(long employeeId) {
		// TODO Auto-generated method stub
		
	}

	public Employee find(long employeeId) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Employee> find(List<Long> employeeIds) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Employee> find(String employeeName) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Employee> find(boolean currentEmployee) {
		// TODO Auto-generated method stub
		return null;
	}

}
